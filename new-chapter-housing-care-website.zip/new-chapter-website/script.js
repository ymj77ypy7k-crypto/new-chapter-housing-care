
const button = document.querySelector('.menu-button');
const nav = document.querySelector('.nav');
if (button && nav) {
  button.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    button.setAttribute('aria-expanded', String(open));
  });
}
const form = document.querySelector('#contact-form');
if (form) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const data = new FormData(form);
    const subject = encodeURIComponent('Website inquiry from ' + (data.get('name') || 'New Chapter visitor'));
    const body = encodeURIComponent(
      'Name: ' + (data.get('name') || '') + '\n' +
      'Phone: ' + (data.get('phone') || '') + '\n' +
      'Email: ' + (data.get('email') || '') + '\n' +
      'Service of interest: ' + (data.get('service') || '') + '\n\n' +
      (data.get('message') || '')
    );
    window.location.href = `mailto:info@newchapterhousingcare.com?subject=${subject}&body=${body}`;
  });
}
