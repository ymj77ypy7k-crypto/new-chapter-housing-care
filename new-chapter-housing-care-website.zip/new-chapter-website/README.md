# New Chapter Housing & Care Services Website

This is a static, mobile-responsive website package for NewChapterHousingCare.com.

## Files
- index.html — homepage
- about.html
- services.html
- resources.html
- contact.html
- privacy.html
- terms.html
- styles.css
- script.js
- assets/ — logo and website imagery

## Preview
Open index.html in a web browser.

## GitHub upload
1. Create a new GitHub repository named `new-chapter-housing-care`.
2. Upload all files and the `assets` folder.
3. Commit the files.

## Cloudflare Pages deployment
1. Create a free Cloudflare account.
2. Go to Workers & Pages → Create → Pages → Connect to Git.
3. Select the GitHub repository.
4. Framework preset: None.
5. Build command: leave blank.
6. Build output directory: `/`
7. Deploy.

## Domain connection
In Cloudflare Pages, add:
- newchapterhousingcare.com
- www.newchapterhousingcare.com

Cloudflare will provide DNS instructions. Enter those records in GoDaddy DNS.

## Important launch checks
- Activate info@newchapterhousingcare.com in GoDaddy/Microsoft 365.
- Test every phone, email, navigation and Spectrum News link.
- Replace the email-based contact form with a secure form service if desired.
- Have the Privacy Policy and Terms reviewed by a qualified attorney/compliance professional.
- Confirm all service descriptions and regulatory statements before publishing.
